email = 'malarahul465@gmail.com'
smtpkey = 'smtp.'+email[13:]
print(type(smtpkey))