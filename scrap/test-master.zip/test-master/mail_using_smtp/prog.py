import smtplib
def sendmail(msg):
	connection = smtplib.SMTP('smtp.gmail.com', 587)
	connection.ehlo()
	connection.starttls()
	connection.login('malarahul465@gmail.com','qwertyr@hul465')
	connection.sendmail('malarahul465@gmail.com','rahulmala18@gmail.com',msg)
	connection.quit()
message_1 = '''<!DOCTYPE html>
<html>
<head>
	<title>email</title>
	<style type="text/css">
		.email-backgound{
	backgorund: #eee;
	padding:10px;
}
.email-container{
	max-width: 500px
	backgrund: white;
	font-family: sans-serif;
	margin: 0 auto;
	overflow: hidden;
	border-radius: 5px;
	text-align: center;
}
img{max-width: 100%;}
a{
	color : #3D87F5;
}
p{
	margin: 20px;
	font-size: 18px;
	font-weight: 300;
	color: #666;
	line-height: 1.5;
}
.cta{
	margin: 20px}
	.cta a {
		text-decoration: none;
		display: inline-block;
		background: #3D87F5;
		color: white;
		padding: 10px 20px 10px;
		border-radius: 5px;
	}

.footer-junk{
	@extent .email-container
	background: none;
	padding: 20px;
	font-size: 12px;
}


	</style>
</head>
<body>
<fieldset>
	<legend>.</legend>
	<div class="email-background">
		<div class="email-container" style="max-width: 500px
	backgrund: white;font-family: sans-serif;margin: 0 auto;overflow: hidden;border-radius: 5px;text-align: center;">
			<img src="logo.jpg" style="max-width: 100%;">
			<h2>Hey user!,</h2>
			<p style="margin: 20px;font-size: 18px;font-weight: 300;color: #666;line-height: 1.5;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbspThanks for signing up for a &lt;our_site/project_name&gt;</p>
			<p style="margin: 20px;font-size: 18px;font-weight: 300;color: #666;line-height: 1.5;">Here's the verification code you need to continue with &lt;our_site/project_name&gt;</p>
			<div class="cta" style="margin: 20px;">
				<a href="'''
link = "#!"
message_2='''"style="color: white;text-decoration: none;display: inline-block;background: #3D87F5;padding: 10px 20px 10px;border-radius: 5px;">Verify</a>
			</div>
			<div class="footer-junk" style="@extent .email-container
	background: none;padding: 20px;font-size: 12px;">
				&lt;our_site/project_name&gt; | <a href="#!" style="color: #3D87F5;">Unsubscribe</a>
			</div>
		</div>
	</div>
</fieldset></body></html>
'''
message = message_1 + link + message_2
sendmail(message)
print("sent")
