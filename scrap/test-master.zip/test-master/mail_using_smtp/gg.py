import os
import smtplib
import imghdr
from email.message import EmailMessage

EMAIL_ADDRESS = os.environ.get('UserName111')
EMAIL_PASSWORD = os.environ.get('Password')

print(EMAIL_ADDRESS,EMAIL_PASSWORD)
