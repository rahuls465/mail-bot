import re
#import sys
import argparse

myargs = argparse.ArgumentParser(
		description = "mail sending program using SMPT"
	)
myargs.add_argument('Email',help='enter email address to which mail is sent')
myargs.add_argument('Link', help='provide the Verification link')
args = myargs.parse_args()


print(args.Email,args.Link)
count = 0
email = args.Email
for at in email:
	count = count + 1
	if at=='@':k = count
	if at=='.':j = count
maildomain = email[k:j-1]



di = {'outlook':587,
'office365':587,
'yahoo':465,
'o2':25,
'AT&T':	465,
'ntlworld':	465,
'btconnect':25,
'orange':25,
'mail':465,
'GMX':465,
'gmail' : 465}
print(di[maildomain])