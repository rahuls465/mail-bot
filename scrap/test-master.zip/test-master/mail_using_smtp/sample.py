import re
mail = 'malarahul465@gmail.com'
key = re.findall("\S+@(*[a-z]).com", mail)

#key = 'outlook'

str={
'mail formats':'smtp out ports',
'gmail':465,
'outlook':587,
'office365':587,
'yahoo':465,
'o2':25,
'AT&T':465,
'ntlworld':465,
'btconnect':25,
'orange':25,
'mail':	465,
'GMX': 465
}
print(str)
print (f"{str[key]}")
