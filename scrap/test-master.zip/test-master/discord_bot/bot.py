import discord
from discord.ext import commands

client = commands.Bot(command_prefix= '.')

@client.event
async def on_ready():
	print("bot is on_ready")

@client.event
async def on_member_join(member):
	print(f'{member} has joined a server.')

@client.event
async def on_member_remove(member):
	print(f'{member} has left the server.')

client.run('NjMwNjQ3OTM5NDMzMjM0NDMy.XZrWwQ.Qmbk1rh-sounHytZRRbeYKXRzy0')
